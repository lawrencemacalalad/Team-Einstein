# HackBio 2020
## Personal Information
Hello! My name is Ekene Ezeunala, and I am a recent high school graduate from Nigeria with a keen interest in data science and analytics and an interest in bioinformatics. 
I have published a data analytics research project with other collaborators, and I am glad to work with the rest of you in a similar activity.
It is a total honor for me to be here, and I am most grateful to be one of you.
|Name                    |Email                  |
|------------------------|-----------------------|
|Ekene Ezeunala          |ezeunalaekene@gmail.com|
