name = 'Ekene Ezeunala'
email = 'ezeunalaekene@gmail.com'
biostack = 'Data Analytics'
slack_username = '@David'
print(name)
print(email)
print(biostack)
print(slack_username)
